import streamlit as st
import pandas as pd
import joblib

# Load trained model
model = joblib.load("best_model.pkl")

st.set_page_config(page_title="Customer Churn Predictor")
st.title("📊 Customer Churn Prediction System")

st.markdown("Enter customer details to predict churn probability.")

# User Inputs
tenure = st.slider("Tenure (Months)", 0, 72, 12)
monthly_charges = st.slider("Monthly Charges", 10.0, 150.0, 50.0)
contract = st.selectbox("Contract Type", ["Month-to-month", "One year", "Two year"])
paperless = st.selectbox("Paperless Billing", ["Yes", "No"])

# Create dataframe
input_data = pd.DataFrame({
    "Tenure": [tenure],
    "MonthlyCharges": [monthly_charges],
    "Contract": [contract],
    "PaperlessBilling": [paperless]
})

if st.button("Predict Churn"):
    prediction = model.predict(input_data)[0]
    probability = model.predict_proba(input_data)[0][1]

    if prediction == 1:
        st.error(f"⚠ High Churn Risk ({probability:.2%})")
    else:
        st.success(f"✅ Low Churn Risk ({probability:.2%})")

st.markdown("---")
st.markdown("Developed as part of Final Capstone Project")
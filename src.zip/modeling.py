# modeling.py

import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    roc_auc_score
)


def split_data(X, y, test_size=0.2):
    return train_test_split(X, y, test_size=test_size, random_state=42)


def train_decision_tree(preprocessor, X_train, y_train):
    pipeline = Pipeline([
        ("preprocessing", preprocessor),
        ("classifier", DecisionTreeClassifier())
    ])
    pipeline.fit(X_train, y_train)
    return pipeline


def train_random_forest(preprocessor, X_train, y_train):
    pipeline = Pipeline([
        ("preprocessing", preprocessor),
        ("classifier", RandomForestClassifier(random_state=42))
    ])

    param_grid = {
        "classifier__n_estimators": [100, 200],
        "classifier__max_depth": [None, 10, 20]
    }

    grid = GridSearchCV(pipeline, param_grid, cv=5, scoring="accuracy")
    grid.fit(X_train, y_train)

    return grid.best_estimator_, grid.best_params_


def evaluate_model(model, X_test, y_test):
    predictions = model.predict(X_test)
    probabilities = model.predict_proba(X_test)[:, 1]

    results = {
        "accuracy": accuracy_score(y_test, predictions),
        "roc_auc": roc_auc_score(y_test, probabilities),
        "classification_report": classification_report(y_test, predictions),
        "confusion_matrix": confusion_matrix(y_test, predictions)
    }

    return results


def cross_validate(model, X, y):
    scores = cross_val_score(model, X, y, cv=5)
    return scores.mean()
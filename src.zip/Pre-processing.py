# preprocessing.py

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline


def load_data(path):
    """
    Load dataset from given path
    """
    df = pd.read_csv(path)
    return df


def clean_data(df):
    """
    Perform data cleaning:
    - Remove duplicates
    - Handle missing values
    - Remove outliers (IQR method)
    """
    df = df.drop_duplicates()

    # Fill missing values
    df.fillna(method="ffill", inplace=True)

    # Outlier removal for MonthlyCharges
    if "MonthlyCharges" in df.columns:
        Q1 = df["MonthlyCharges"].quantile(0.25)
        Q3 = df["MonthlyCharges"].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        df = df[(df["MonthlyCharges"] >= lower) & (df["MonthlyCharges"] <= upper)]

    return df


def feature_engineering(df):
    """
    Create new engineered features
    """
    if "MonthlyCharges" in df.columns and "Tenure" in df.columns:
        df["Customer_Lifetime_Value"] = df["MonthlyCharges"] * df["Tenure"]

    if "TotalCharges" in df.columns:
        df["Avg_Charge_Per_Tenure"] = df["TotalCharges"] / (df["Tenure"] + 1)

    return df


def build_preprocessor(df, target_column="Churn"):
    """
    Create preprocessing pipeline
    """
    X = df.drop(target_column, axis=1)

    categorical_cols = X.select_dtypes(include="object").columns
    numeric_cols = X.select_dtypes(include=["int64", "float64"]).columns

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), numeric_cols),
            ("cat", OneHotEncoder(drop="first"), categorical_cols)
        ]
    )

    return preprocessor
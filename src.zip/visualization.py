# visualization.py

import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import roc_curve


def plot_churn_distribution(df):
    sns.countplot(x="Churn", data=df)
    plt.title("Churn Distribution")
    plt.show()


def plot_confusion_matrix(cm):
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
    plt.title("Confusion Matrix")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()


def plot_roc_curve(model, X_test, y_test):
    probs = model.predict_proba(X_test)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, probs)

    plt.plot(fpr, tpr)
    plt.plot([0, 1], [0, 1], "--")
    plt.title("ROC Curve")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.show()


def plot_feature_importance(model):
    classifier = model.named_steps["classifier"]
    importances = classifier.feature_importances_

    feature_names = model.named_steps["preprocessing"].get_feature_names_out()

    import pandas as pd
    importance_df = pd.Series(importances, index=feature_names)
    importance_df.sort_values(ascending=False).head(10).plot(kind="bar")

    plt.title("Top Feature Importance")
    plt.show()